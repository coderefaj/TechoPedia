import { CodeMirror } from "./edit/main"

export default CodeMirror
