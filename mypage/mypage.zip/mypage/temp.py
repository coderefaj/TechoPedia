print "hello world"
